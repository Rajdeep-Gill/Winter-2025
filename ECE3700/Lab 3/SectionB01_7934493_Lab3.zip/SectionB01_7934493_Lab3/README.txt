Name: Rajdeep Gill
Student ID: 7934493
email: gillr10@myumanitoba.ca

To run this project, open with netbeans and run the main class located in src/lab3/b01/RajdeepGill/logic/Project.java

Then input the parameters you want to simulate and output will display the simulation time, and throughput.