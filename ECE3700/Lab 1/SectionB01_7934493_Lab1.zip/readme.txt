Name: Rajdeep Gill
ID: 007934493
Email: gillr10@myumanitoba.ca

All included information is provided inside the Lab report titled SectionB01_7934493