Name: Rajdeep Gill
Student ID: 7934493
Emai: gillr10@myumanitoba.ca

Part A:
- Compile and run WebServer.java, and visit localhost:5000 to see the input response.
- The response will be displayed in the console where you ran the webserver

Part B:
- Have the file(s) you want to serve in the same directory you are running it in
- Compile and run WebServer.java, and visit localhost:5000/<file name>
- If the file exists in the directory then the server will send over the file and you can see it's contents if its an html, jpg or gif file
- If the file does not exist, a basic html file with content saying the requested file does not exist. 
